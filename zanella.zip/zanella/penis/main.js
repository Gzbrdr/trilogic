const button = document.getElementById('btn')
const paragrafo = document.getElementById('amogus')
const distanciaDiv = document.getElementById('distancia')
const tempoDiv = document.getElementById('tempo')

function alertaSol() {
    alert('segundo nossos cálculos, a massa do sol é 1,98892 × 10<sup>30</sup> quilogramas')
}

function veloMédia(distancia, tempo) {
    return distancia/tempo
}

button.addEventListener('click', () => {
    const [distancia, tempo] = [distanciaDiv.value, tempoDiv.value]
    const velocidadeMedia = veloMédia(parseFloat(distancia), parseFloat(tempo))
    paragrafo.innerHTML = velocidadeMedia
})