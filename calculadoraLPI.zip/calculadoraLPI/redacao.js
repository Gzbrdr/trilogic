$(document).ready(
    function() {
        //contador para alert de espacos em inicio de paragrafo
        var contAlertaEspaco = 0
        $("#redacao").on("input keypress", function(event) {
            const redacao = $(this).val()
            const caracteresDigitados = redacao.length;
            var palavrasDigitadas = caracterSemRepeticao(redacao, ' ')
            var paragrafos = caracterSemRepeticao(redacao, '\n')
            palavrasDigitadas += Number(Boolean(redacao)) //evitar bug de uma palavra digitada sem nada escrito
            palavrasDigitadas += paragrafos //contar a palavra mesmo depois de um parágrafo
            console.log(paragrafos);


            //conta os caracteres de um texto sem repetição (um atrás do outro)
            function caracterSemRepeticao(texto, caracter) {
                const caracteresDoTexto = texto.split('')
                const posicoes = []
                var quantCaracNaoRepetidos = 0
                for (i = 0; i < caracteresDoTexto.length; i++) {
                    if (caracteresDoTexto[i] == caracter) {
                        posicoes.push(i)
                    }
                }
                posicoes.forEach(element => {
                    const caracterDepois = caracteresDoTexto[element+1]
                    const caracDepoisNaoEhIgual = (caracterDepois != '\n' && caracterDepois != ' ')
                    if (caracterDepois && caracDepoisNaoEhIgual){
                        quantCaracNaoRepetidos++
                    }
                })
                return quantCaracNaoRepetidos;
            }

            $("#caracteres").text('caracteres: ' + caracteresDigitados);
            $("#palavras").text('palabras: ' +palavrasDigitadas);
        });
    })

    
    const drag = document.getElementById('logo')
    $('#logo').click(() => {
        $('.pong').toggle()
        $('.pong').html('<iframe width="100%" height="100%" src="https://zanellaz.github.io/five-if-pong/" frameborder="0"></iframe>')
        document.documentElement.requestFullscreen()
    })
    drag.style.position = 'absolute'
console.log(drag);
drag.style.left = '0px'
drag.style.top = '0px'

let xAtual
let yAtual
let naHoraDoClickX
let naHoraDoClickY
let dragTarget

function styleLeft(element) {
    const left = element.style.left
    return parseInt(left.replace('px'))
}

function styleTop(element) {
    const top = element.style.top
    return parseInt(top.replace('px'))
}

function arrasta({pageX, pageY}) {
    const xFinal = pageX - xAtual 
    const yFinal = pageY - yAtual
    const newX = naHoraDoClickX + xFinal + 'px'
    const newY = naHoraDoClickY + yFinal + 'px'
    console.log(newX);
    console.log(newY);
    dragTarget.style.left = newX
    dragTarget.style.top = newY
}

document.addEventListener('mousedown', ({ target, pageX, pageY }) => {
    dragTarget = target
    xAtual = pageX 
    yAtual = pageY
    naHoraDoClickX = styleLeft(dragTarget)
    naHoraDoClickY = styleTop(dragTarget)
    document.addEventListener('mousemove', arrasta)
})

document.addEventListener('mouseup', () => {
    naHoraDoClickX = styleLeft(dragTarget)
    naHoraDoClickY = styleTop(dragTarget)
    document.removeEventListener('mousemove', arrasta)
})